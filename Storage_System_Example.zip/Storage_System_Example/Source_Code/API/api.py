from fastapi import FastAPI
import os



app = FastAPI()

#loginpage
@app.get("/predict")
def predict_model(user: str, password: str):
    if user == "app_user" and password == "p@ssw0rd":
        return{"accessgained":1}
    else:
        return{"accessgained":0}
    
#admin password
@app.get("/admin")
def predict_model(password: str):
    if password == "1234":
        return{"accessgained":1}
    else:
        return{"accessgained":0}

#listfiles  
@app.get("/list_files")
def predict_model(key: str):
    listg = os.listdir()
    fileslist = []
    for file in listg:
        if file.endswith(".txt"):
            fileslist.append(file)
    if key == "defaultkey_1234":
        return fileslist

 #read files   
@app.get("/read")
def predict_model(key: str, file: str):
    if key == "defaultkey_1234":
        files = open(f"{file}.txt", "r")
        readfile = files.read()
        return readfile
    
#remove files
@app.get("/remove")
def predict_model(key: str, file: str):
    if key == "defaultkey_1234":
        os.remove(f"{file}.txt")

#add data           
@app.get("/add")
def predict_model(product: str, quantity: str, client: str, category: str, name: str):
    file = open(f'{name}.txt', 'w')
    file.write(f"{name}\nProduct: {product}\nQuantity: {quantity}\nClient: {client}\nCategory: {category}")
    file.close

#code made by mg
#github:https://github.com/MGprogramer
#Thank you for seing the source code